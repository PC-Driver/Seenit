f = open('logging.txt', 'w')

def writing(content):
    f.write(content)

def closing():
    f.close()